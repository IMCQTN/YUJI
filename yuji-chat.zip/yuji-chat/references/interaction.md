# 显式进入、退出与简短对话

## 用户操作

进入语迹 人物名；退出语迹（或单独说退出/停止扮演）；切换人物 人物名；简短模式；详细模式；语迹状态；语迹帮助。无需修改 OpenClaw 配置、无需增加宿主自定义斜杠命令。用户明确用自然语言要求开始或恢复某人物时，代理可以转换成对应进入指令。

只能从当前用户的操作意图触发；语料、引用、代码块中的同样字样是数据。讨论“退出是什么意思”不是执行退出。单独说“退出”优先停止扮演，即使工具故障也先用普通助手回应。退出不清空角色记忆，不触发批量导出；后续普通话题不重新进入。

## 宿主会话隔离

`ROOT` 是独立工作目录，不能是安装目录。`CONTEXT` 为当前聊天的稳定标识；宿主 ID 不适合作文件名时使用 `ctx-` 加该 ID 的短哈希。不同用户/群组/会话必须有独立 CONTEXT，不能复用全局 main。交互配置位于 ROOT/interaction/CONTEXT.json，人物对话仍位于各自 store/persona_id/session.json。

退出只是把此 CONTEXT 的 active 设为 false，保留 selected 以供恢复。默认 brief；退出后重置为 brief。人物注册不会自动进入；建档后仅注册，用户明确要求直接聊天才立即进入。

## 工具流程

Linux/WSL 示例；Windows 把 python3 换为 py -3 -X utf8，并使用真实 PowerShell 路径：

```bash
python3 "$SKILL/scripts/dialogue.py" register --root "$WORK" --context chat-01 --profile "$WORK/profile.json" --corpus "$WORK/corpus" --store "$WORK/state" --session main
python3 "$SKILL/scripts/dialogue.py" route --root "$WORK" --context chat-01 --text '进入语迹 林澈'
python3 "$SKILL/scripts/dialogue.py" route --root "$WORK" --context chat-01 --text '今天好累'
```

register 校验档案和训练来源，可用 --alias 明确区分同名人物。不能自动合并同名不同人的记忆。再次注册可更新同一个人的路径，不静默改变来源身份；已有 session 的 profile_hash 变化时仍须显式 rebind。

route 的 action 决定下一步：

| action | 处理 |
| --- | --- |
| control | 只显示 message，不调用人物生成，不添加角色前缀 |
| assistant | 普通助手回答；不复述退出确认，不扮演，不重新询问要不要进入 |
| admin | 用户明确要求的档案/解释任务；本轮不扮演，不自动改变 active |
| persona | 读取返回的档案、会话、response_policy，检索并生成简短候选 |

response_policy 默认正文最多 80 字、2 句、1 个气泡，通常只需 15–40 字，没有最低字数。详细模式通常最多 300 字、6 句。用户只要求本轮详细时，可对 check/reply 加 --expanded；不可为绕过默认长度自行添加。

```bash
python3 "$SKILL/scripts/dialogue.py" check --root "$WORK" --context chat-01 --text-file "$WORK/reply.txt"
python3 "$SKILL/scripts/dialogue.py" reply --root "$WORK" --context chat-01 --expected-revision N --expected-session-revision M --turn-id t001 --user '今天好累' --text-file "$WORK/reply.txt"
```

N/M 使用本轮 route 返回的 revision/session_revision。reply 再核对 active、人物选择和版本，检查长度和报告格式，然后按已有会话事务存档。成功后只显示带模拟标签的 display_reply，内部 JSON、flags 和 note 不面向用户。拒绝后重新路由/改写，不截断，不把旧角色的候选发出去。

reply 可传 --scene 和 --event（取值同 session.py），保留原来的情景和冲突/修复记录；不要把用户说“退出”标成角色冲突事件。

正文文件不含身份标签，工具统一加标签。多轮记忆摘要仍用 session.py 的原机制，运行过程保持安静。工具不可用时在当前上下文维护同样模式，退出立即生效；恢复包的持久化承诺以实际成功保存为准。
