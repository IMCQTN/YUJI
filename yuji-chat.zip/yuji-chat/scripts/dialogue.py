"""Explicit enter/exit routing and concise replies, isolated by host conversation."""
from __future__ import annotations
import argparse
import re
from pathlib import Path
from common import *
import session
import profile as profiles

def state_paths(root, context):
    base = Path(root) / "interaction"
    return base / (identifier(context) + ".json"), base / (context + ".lock")

def read_state(root, context):
    path, _ = state_paths(root, context)
    if not path.exists():
        return {"schema_version": 1, "revision": 0, "active": False,
                "selected": None, "length": "brief", "bindings": {}}
    state = read_json(path)
    require(state.get("schema_version") == 1 and isinstance(state.get("bindings"), dict), "交互状态格式错误")
    require(type(state.get("active")) is bool and state.get("length") in ("brief", "detailed"), "交互模式无效")
    require(state.get("selected") is None or state["selected"] in state["bindings"], "人物绑定缺失")
    return state

def persist(root, context, state):
    state["revision"] += 1
    write_json(state_paths(root, context)[0], state)

def alias_name(value):
    require(isinstance(value, str) and 0 < len(value.strip()) <= 64 and "\n" not in value and "\r" not in value, "人物名称需为 1–64 字符的单行文本")
    return value.strip()

def register(root, context, profile_path, corpus, store, sid, alias=None):
    profile = session.checked_profile(profile_path)
    report = profiles.validate(profile, corpus)
    require(report["valid"], "人物档案证据校验未通过，请先修复档案")
    alias = alias_name(alias or profile["target"])
    identifier(sid)
    binding = {"persona_id": profile["persona_id"], "profile": str(Path(profile_path).resolve()),
               "corpus": str(Path(corpus).resolve()), "store": str(Path(store).resolve()), "session": sid}
    with lock(state_paths(root, context)[1]):
        state = read_state(root, context)
        old = state["bindings"].get(alias)
        require(not old or old["persona_id"] == profile["persona_id"], "同名但不同人物，请指定独立 alias")
        state["bindings"][alias] = binding
        persist(root, context, state)
    return {"registered": alias, "active": state["active"], "revision": state["revision"]}

def parse_command(text):
    text = text.strip().rstrip("。！!？?").strip()
    if text in ("退出语迹", "退出", "退出角色", "停止扮演", "结束扮演", "返回普通AI", "返回普通 AI", "返回普通对话", "暂停语迹"):
        return "exit", None
    if text in ("进入语迹", "进入", "开始语迹", "恢复语迹", "继续语迹"):
        return "enter", None
    for prefix in ("进入语迹 ", "进入语迹：", "进入语迹:", "恢复语迹 ", "切换人物 ", "切换人物：", "切换人物:", "开始扮演 ", "继续扮演 "):
        if text.startswith(prefix) and text[len(prefix):].strip():
            return "enter", alias_name(text[len(prefix):])
    if text in ("简短模式", "少说点", "说短一点"):
        return "brief", None
    if text == "详细模式":
        return "detailed", None
    if text in ("语迹状态", "查看语迹状态"):
        return "status", None
    if text in ("语迹帮助", "语迹指令"):
        return "help", None
    if text in ("导演模式", "查看档案", "查看依据", "语迹分析"):
        return "admin", text
    return None, None

def policy(state, expanded=False):
    detailed = expanded or state["length"] == "detailed"
    return {"length": "detailed" if detailed else "brief", "preferred_chars": "15–40" if not detailed else "按明确要求",
            "max_chars": 300 if detailed else 80, "max_sentences": 6 if detailed else 2,
            "max_bubbles": 1, "analysis_visible": False,
            "instruction": "只回复眼前这一件事；不附建议清单、报告或追问尾巴。需要澄清时最多问一个问题。"}

def ensure_session(binding):
    profile = session.checked_profile(binding["profile"])
    require(profile["persona_id"] == binding["persona_id"], "人物档案身份改变，请重新注册")
    path = session.paths(binding["store"], profile["persona_id"], binding["session"])[0]
    if not path.exists():
        session.new(binding["store"], profile, binding["session"])
    state = session.load(binding["store"], profile, binding["session"])
    return profile, state

def route(root, context, text):
    """Only the current outer user message belongs here, never corpus/quoted text."""
    command, arg = parse_command(text)
    with lock(state_paths(root, context)[1]):
        state = read_state(root, context)
        if command == "exit":
            state["active"] = False
            state["length"] = "brief"
            persist(root, context, state)
            return {"action": "control", "message": "已退出语迹，恢复普通对话。", "active": False, "revision": state["revision"]}
        if command == "enter":
            name = arg or state["selected"]
            if not name and len(state["bindings"]) == 1:
                name = next(iter(state["bindings"]))
            if not name:
                return {"action": "control", "message": "想进入哪个人物？" if state["bindings"] else "先发语料，并告诉我要模仿谁。", "revision": state["revision"]}
            if name not in state["bindings"]:
                suffix = f"当前仍是{state['selected']}（模拟）。" if state["active"] else ""
                return {"action": "control", "message": f"没有找到{name}的档案，请先提供语料。" + suffix, "revision": state["revision"]}
            ensure_session(state["bindings"][name])
            state.update({"active": True, "selected": name})
            persist(root, context, state)
            return {"action": "control", "message": f"已进入{name}（模拟）；说“退出语迹”即可返回。", "active": True, "revision": state["revision"]}
        if command in ("brief", "detailed"):
            state["length"] = command
            persist(root, context, state)
            return {"action": "control", "message": "好，我说短一点。" if command == "brief" else "已开启详细模式。", "revision": state["revision"]}
        if command == "help":
            return {"action": "control", "message": "进入语迹 人物名｜退出语迹｜切换人物 人物名｜简短模式｜详细模式｜语迹状态", "revision": state["revision"]}
        if command == "status":
            return {"action": "control", "message": (f"当前：{state['selected']}（模拟），" + ("简短" if state["length"] == "brief" else "详细") + "模式。") if state["active"] else "当前是普通对话，语迹未开启。", "revision": state["revision"]}
        if command == "admin":
            return {"action": "admin", "topic": arg, "revision": state["revision"], "selected": state["selected"]}
        if not state["active"]:
            return {"action": "assistant", "revision": state["revision"], "instruction": "正常回答用户，不使用人物语气、不复述退出提示；不得因话题相似自动重新进入。"}
        binding = state["bindings"][state["selected"]]
        profile, saved = ensure_session(binding)
        return {"action": "persona", "alias": state["selected"], **binding,
                "label": profile["representation"]["display_label"], "revision": state["revision"],
                "session_revision": saved["revision"], "response_policy": policy(state)}

def review_text(text, response_policy):
    body = text.strip()
    flags = []
    if not body:
        flags.append("empty_reply")
    if len(body) > response_policy["max_chars"]:
        flags.append("too_long")
    if len([x for x in body.splitlines() if x.strip()]) > response_policy["max_bubbles"]:
        flags.append("too_many_bubbles")
    sentences = len(re.findall(r"[。！？!?]+|(?<!\.)\.(?!\.)", body))
    if body and not re.search(r"[。！？!?\.]$", body):
        sentences += 1
    if sentences > response_policy["max_sentences"]:
        flags.append("too_many_sentences")
    if re.search(r"(?m)^\s*(?:#{1,6}\s|[-*]\s|\d+[.)、]\s)|\*\*", body):
        flags.append("report_format")
    return {"allowed": not flags, "flags": flags, "characters": len(body), "sentences": sentences}

def check(root, context, text, expanded=False):
    state = read_state(root, context)
    if not state["active"]:
        return {"allowed": False, "flags": ["persona_not_active"]}
    return review_text(text, policy(state, expanded))

def reply(root, context, expected, expected_session, tid, user, text, expanded=False, scene="general", event="neutral"):
    with lock(state_paths(root, context)[1]):
        state = read_state(root, context)
        require(state["active"], "语迹已退出，不能继续提交人物回复")
        require(state["revision"] == expected, "进入/退出或人物已改变，请重新路由当前请求")
        require(parse_command(user)[0] is None, "管理指令不能写成人物对话")
        result = review_text(text, policy(state, expanded))
        require(result["allowed"], "回复需重写：" + ", ".join(result["flags"]))
        binding = state["bindings"][state["selected"]]
        profile, _ = ensure_session(binding)
        saved = session.turn(binding["store"], profile, binding["session"], expected_session, tid, user, text.strip(), scene, event)
        return {"display_reply": saved["display_reply"], "session_revision": saved["revision"], "revision": state["revision"]}

def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)
    for name in ("register", "route", "check", "reply"):
        s = sub.add_parser(name)
        s.add_argument("--root", required=True)
        s.add_argument("--context", required=True)
        if name == "register":
            for flag in ("profile", "corpus", "store", "session"):
                s.add_argument("--" + flag, required=True)
            s.add_argument("--alias")
        elif name == "route":
            s.add_argument("--text", required=True)
        else:
            s.add_argument("--text-file", required=True)
            s.add_argument("--expanded", action="store_true", help="Only when the current user explicitly asks for detail")
            if name == "reply":
                s.add_argument("--expected-revision", type=int, required=True)
                s.add_argument("--expected-session-revision", type=int, required=True)
                s.add_argument("--turn-id", required=True)
                s.add_argument("--user", required=True)
                s.add_argument("--scene", default="general")
                s.add_argument("--event", choices=session.EVENTS, default="neutral")
    a = p.parse_args()
    if a.command == "register": result = register(a.root, a.context, a.profile, a.corpus, a.store, a.session, a.alias)
    elif a.command == "route": result = route(a.root, a.context, a.text)
    else:
        text = Path(a.text_file).read_text(encoding="utf-8-sig")
        result = check(a.root, a.context, text, a.expanded) if a.command == "check" else reply(a.root, a.context, a.expected_revision, a.expected_session_revision, a.turn_id, a.user, text, a.expanded, a.scene, a.event)
    print_result(result)

if __name__ == "__main__":
    run_cli(main)
